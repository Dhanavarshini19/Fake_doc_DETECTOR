import re

def clean_text(text):
    return re.sub(r'[^A-Za-z0-9\s]', '', text)

def get_text_features(text):
    features = {
        "text_length": len(text),
        "num_words": len(text.split()),
        "num_special_chars": len(re.findall(r'[^A-Za-z0-9\s]', text)),
        "num_digits": len(re.findall(r'\d', text)),
        "num_uppercase": len(re.findall(r'[A-Z]', text))
    }
    return features