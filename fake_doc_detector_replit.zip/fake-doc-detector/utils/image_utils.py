import cv2

def calculate_blur_score(image_path):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    return cv2.Laplacian(image, cv2.CV_64F).var()

def get_image_features(image_path):
    return {"blur_score": calculate_blur_score(image_path)}